## How to compile
- type the command `gcc –o tran transmit.c bit_manipulation.c`
- then typeing `./tran` will begin the program

## How to interact with the program

This program will prompt you for an input which you will then type (letters) and it will transmit back to you the
numeric representation of your string
