## How to compile
- type the command `gcc –o recv receive.c bit_manipulation.c`
- then typeing `./recv` will begin the program

## How to interact with the program

This program will prompt you for an input. Take the numeric representation of your word that was the
result of transmit.c and it will transmit back to you the `Transmitted Message` and the `Corrected Transmitted Message` as a string.