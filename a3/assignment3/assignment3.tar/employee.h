#ifndef _employee_h
#define _employee_h

#include "struct.h"

void printAllEmployees(struct person e[], int arraySize);
void printEmployee(struct person e);

#endif