the purpose was to become familiar with pointers and linkedlist
Made by:owen craston
S#: 101037159
Date:november 27th 2016
to compile:type make
to run: type ./a.out, This will run the executable 

This will run several tests and print the results

Limitations/problems:
Some of the functions do not handle every edge case and some functions do not work entirley
an example of this is the removeDuplicates function();
another limitation is that these functions only work with the PersonalInfo struct and are not completley general purpose linkedlist functions.

