the purpose was to become familira with pointers and linkedlist
owen craston
november 26th 2016
to compile: make
